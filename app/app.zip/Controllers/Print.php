<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Print extends BaseController
{
    public function index()
    {
        //
    }
}
